# Open Resume Builder - Production Deployment

## 🚀 Quick Start

1. **Extract the archive**:
   ```bash
   tar -xzf open-resume-builder-*.tar.gz
   cd open-resume-builder/
   ```

2. **Configure environment**:
   ```bash
   cp .env.production .env.local
   nano .env.local  # Edit with your production settings
   ```

3. **Deploy**:
   ```bash
   ./deploy-production.sh
   ```

## 📋 Production Checklist

### Before Deployment
- [ ] Set up MariaDB/MySQL database
- [ ] Configure firewall (open necessary ports)
- [ ] Set up domain/SSL certificates
- [ ] Configure reverse proxy (nginx recommended)
- [ ] Set up monitoring/logging

### Environment Variables
Edit `.env.local` with:

```bash
# Database (REQUIRED)
DATABASE_URL="mysql://user:pass@db-host:3306/db_name"

# OpenAI (OPTIONAL)
OPENAI_API_KEY="sk-your-key"

# Application
NEXT_PUBLIC_APP_URL="https://your-domain.com"
NODE_ENV="production"
```

### Database Setup
```bash
# Create database
mysql -u root -p
CREATE DATABASE open_resume CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'app_user'@'localhost' IDENTIFIED BY 'secure_password';
GRANT ALL PRIVILEGES ON open_resume.* TO 'app_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

## 🔧 Production Configuration

### Using systemd (recommended)
```bash
sudo cp open-resume.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable open-resume
sudo systemctl start open-resume
```

### Using PM2
```bash
npm install -g pm2
pm2 start npm --name "open-resume" -- start
pm2 startup
pm2 save
```

### Using Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY . .
RUN npm ci --only=production
RUN npm run build
EXPOSE 3033
CMD ["npm", "start"]
```

## 🔒 Security Considerations

- Use strong database passwords
- Enable SSL/TLS
- Configure firewall properly
- Keep dependencies updated
- Use environment variables for secrets
- Enable logging and monitoring
- Regular backups

## 📊 Monitoring

### Application Logs
```bash
# systemd
sudo journalctl -u open-resume -f

# PM2
pm2 logs open-resume
```

### Health Checks
```bash
curl http://localhost:3033/api/health
```

## 🚀 Scaling

### Load Balancing
- Use nginx as reverse proxy
- Set up multiple application instances
- Use Redis for session storage
- Implement database connection pooling

### Performance Optimization
- Enable gzip compression
- Set up CDN for static assets
- Configure database indexes
- Use caching strategies
- Monitor resource usage

## 🔄 Updates

To update the application:
```bash
# Stop the service
sudo systemctl stop open-resume

# Backup database
./backup-db.sh

# Extract new version
tar -xzf open-resume-builder-new-version.tar.gz

# Update dependencies
npm ci --only=production
npm run build
npx prisma db push

# Start service
sudo systemctl start open-resume
```

## 🆘 Troubleshooting

### Common Issues

**Application won't start**:
```bash
# Check logs
sudo journalctl -u open-resume -n 50

# Check database connection
mysql -u app_user -p open_resume -e "SELECT 1"

# Check environment variables
cat .env.local
```

**Database connection errors**:
```bash
# Verify database exists
mysql -u root -p -e "SHOW DATABASES;"

# Check user permissions
mysql -u root -p -e "SELECT User, Host FROM mysql.user WHERE User='app_user';"
```

**Port already in use**:
```bash
# Find what's using the port
sudo netstat -tlnp | grep :3033

# Change port in .env.local
echo "PORT=3034" >> .env.local
```

**Memory issues**:
```bash
# Check system resources
free -h
df -h

# Increase Node.js memory limit
export NODE_OPTIONS="--max-old-space-size=4096"
```

## 📞 Support

For production issues:
1. Check application logs
2. Verify database connectivity
3. Confirm environment configuration
4. Check system resources
5. Review firewall settings

---

**🎉 Happy Production Deploying!**
