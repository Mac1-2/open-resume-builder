"use client";

import * as React from "react";
import {useState, useEffect, useCallback} from "react";
import {useRouter} from "next/navigation";
import dynamic from "next/dynamic";
import {Card} from "@/components/ui/card";
import {Button} from "@/components/ui/button";
import {Input} from "@/components/ui/input";
import {ScrollArea} from "@/components/ui/scroll-area";
import {Separator} from "@/components/ui/separator";
import {Tabs, TabsContent, TabsList, TabsTrigger} from "@/components/ui/tabs";
import {Badge} from "@/components/ui/badge";
import {Avatar, AvatarFallback, AvatarImage} from "@/components/ui/avatar";
import {cn} from "@/lib/utils";
import {
  FileText,
  Download,
  Share2,
  Save,
  Palette,
  Settings,
  Eye,
  Edit,
  Plus,
  Sparkles,
  MessageSquare,
  User,
  Briefcase,
  GraduationCap,
  Lightbulb,
  FolderOpen,
  Award,
  Languages,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  Loader2,
  CheckCircle2,
  Circle,
  Brain,
  Zap,
  Wand2,
  Target,
  TrendingUp,
} from "lucide-react";
import {useResumeStore} from "@/store/useResumeStore";
import {useAIChatStore} from "@/store/useAIChatStore";
import TemplateSelector from "@/components/resume/TemplateSelector";
import AIChat from "@/components/ai/AIChat";

// Dynamic import for PDF download to reduce bundle size
const PDFExportButton = dynamic(
  () => import("@/components/resume/PDFExport").then((mod) => mod.PDFExport),
  {ssr: false}
);

interface Section {
  id: string;
  label: string;
  icon: React.ReactNode;
  completed: boolean;
  required: boolean;
}

const SECTIONS: Section[] = [
  {id: "personal", label: "Personal Info", icon: <User className="h-4 w-4" />, completed: false, required: true},
  {id: "summary", label: "Summary", icon: <FileText className="h-4 w-4" />, completed: false, required: false},
  {id: "experience", label: "Experience", icon: <Briefcase className="h-4 w-4" />, completed: false, required: true},
  {id: "education", label: "Education", icon: <GraduationCap className="h-4 w-4" />, completed: false, required: false},
  {id: "skills", label: "Skills", icon: <Lightbulb className="h-4 w-4" />, completed: false, required: true},
  {id: "projects", label: "Projects", icon: <FolderOpen className="h-4 w-4" />, completed: false, required: false},
  {id: "certifications", label: "Certifications", icon: <Award className="h-4 w-4" />, completed: false, required: false},
  {id: "languages", label: "Languages", icon: <Languages className="h-4 w-4" />, completed: false, required: false},
];

const QUICK_ACTIONS = [
  {id: "improve", label: "✨ Improve Bullets", icon: <Wand2 className="h-4 w-4" />, description: "Enhance impact"},
  {id: "grammar", label: "✓ Grammar Check", icon: <Target className="h-4 w-4" />, description: "Fix errors"},
  {id: "skills", label: "🔧 Suggest Skills", icon: <Lightbulb className="h-4 w-4" />, description: "Add relevant skills"},
  {id: "ats", label: "📊 ATS Optimize", icon: <TrendingUp className="h-4 w-4" />, description: "Pass scanners"},
];

export default function ResumeBuilderPage() {
  const router = useRouter();
  const [activeSection, setActiveSection] = useState("personal");
  const [leftPanelOpen, setLeftPanelOpen] = useState(true);
  const [rightPanelOpen, setRightPanelOpen] = useState(true);
  const [showTemplates, setShowTemplates] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [activeTab, setActiveTab] = useState<"edit" | "preview">("edit");
  const [aiChatOpen, setAiChatOpen] = useState(true);

  const {currentResume, updateResume, createResume} = useResumeStore();
  const {createChat, currentChatId} = useAIChatStore();

  // Resume data state
  const [resumeData, setResumeData] = useState({
    personalInfo: {
      fullName: "",
      email: "",
      phone: "",
      location: "",
      photo: "",
      title: "",
      summary: "",
      website: "",
      linkedin: "",
      github: "",
    },
    experience: [],
    education: [],
    skills: [],
    projects: [],
    certifications: [],
    languages: [],
    references: [],
  });

  // Auto-save effect
  useEffect(() => {
    const autoSave = setInterval(() => {
      handleSave(true);
    }, 30000); // Auto-save every 30 seconds

    return () => clearInterval(autoSave);
  }, [resumeData]);

  const handleSave = useCallback(async (silent = false) => {
    if (!silent) setIsSaving(true);
    try {
      // Update store
      updateResume("current", resumeData);
      
      // Save to database if we have a resumeId
      // TODO: Implement database save
      
      setLastSaved(new Date());
      console.log("Resume saved:", resumeData);
    } catch (error) {
      console.error("Error saving resume:", error);
    } finally {
      if (!silent) setIsSaving(false);
    }
  }, [resumeData, updateResume]);

  const updatePersonalInfo = useCallback((field: string, value: string) => {
    setResumeData((prev) => ({
      ...prev,
      personalInfo: {
        ...prev.personalInfo,
        [field]: value,
      },
    }));
  }, []);

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const completionRate = Math.round(
    (Object.values(resumeData).filter(Boolean).length / SECTIONS.length) * 100
  );

  return (
    <div className="flex h-screen flex-col bg-gradient-to-br from-background via-background to-muted/20">
      {/* Top Header */}
      <header className="flex items-center justify-between border-b bg-card/80 backdrop-blur-sm px-6 py-3">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => router.push("/")}
            className="hover:bg-primary/10"
          >
            <FileText className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Open Resume
            </h1>
            <Badge variant="secondary" className="text-xs">
              Beta
            </Badge>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Template Selector */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowTemplates(true)}
            className="gap-2"
          >
            <Palette className="h-4 w-4" />
            Templates
            <Badge variant="outline" className="ml-1 text-xs">
              {currentResume?.template || "Modern"}
            </Badge>
          </Button>

          {/* Auto-save indicator */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            {isSaving ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : lastSaved ? (
              <>
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                Saved {lastSaved.toLocaleTimeString()}
              </>
            ) : (
              <>
                <Circle className="h-4 w-4" />
                Not saved
              </>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => {}}>
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
            
            <PDFExportButton data={resumeData}>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                PDF
              </Button>
            </PDFExportButton>

            <Button size="sm" onClick={() => handleSave()}>
              <Save className="mr-2 h-4 w-4" />
              Save
            </Button>
          </div>

          {/* User Avatar */}
          <Avatar className="h-8 w-8 border-2 border-primary/20">
            <AvatarImage src="" />
            <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-primary-foreground">
              {getInitials(resumeData.personalInfo.fullName || "JD")}
            </AvatarFallback>
          </Avatar>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar - Navigation */}
        <aside
          className={cn(
            "flex flex-col border-r bg-card/50 backdrop-blur-sm transition-all duration-300",
            leftPanelOpen ? "w-72" : "w-16"
          )}
        >
          <div className="flex items-center justify-between p-4">
            {leftPanelOpen && (
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                  Sections
                </h2>
                <p className="text-xs text-muted-foreground mt-1">
                  {completionRate}% complete
                </p>
              </div>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLeftPanelOpen(!leftPanelOpen)}
              className="ml-auto"
            >
              {leftPanelOpen ? (
                <ChevronLeft className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </Button>
          </div>

          {leftPanelOpen && (
            <div className="px-4 mb-4">
              <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-primary to-secondary h-full rounded-full transition-all duration-500"
                  style={{width: `${completionRate}%`}}
                />
              </div>
            </div>
          )}

          <ScrollArea className="flex-1">
            <nav className="p-2 space-y-1">
              {SECTIONS.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all",
                    activeSection === section.id
                      ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
                      : "hover:bg-accent hover:text-accent-foreground"
                  )}
                >
                  <span className="flex-shrink-0">{section.icon}</span>
                  {leftPanelOpen && (
                    <>
                      <span className="flex-1 text-left">{section.label}</span>
                      {section.completed ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      ) : (
                        <Circle className="h-4 w-4 text-muted-foreground/50" />
                      )}
                    </>
                  )}
                </button>
              ))}

              {/* Add Section Button */}
              <button
                className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:bg-accent hover:text-accent-foreground border-2 border-dashed border-muted-foreground/20 mt-4"
              >
                <Plus className="h-4 w-4" />
                {leftPanelOpen && "Add Section"}
              </button>
            </nav>
          </ScrollArea>

          {/* Quick AI Actions */}
          {leftPanelOpen && (
            <div className="p-4 border-t">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                AI Assistant
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {QUICK_ACTIONS.map((action) => (
                  <Button
                    key={action.id}
                    variant="outline"
                    size="sm"
                    className="h-auto flex-col p-3 gap-1"
                    onClick={() => {
                      setAiChatOpen(true);
                      // TODO: Trigger specific AI action
                    }}
                  >
                    {action.icon}
                    <span className="text-xs font-medium">{action.label}</span>
                  </Button>
                ))}
              </div>
              
              {/* AI Chat Toggle */}
              <Button
                variant="default"
                size="sm"
                className="w-full mt-3 gap-2"
                onClick={() => setAiChatOpen(!aiChatOpen)}
              >
                <Brain className="h-4 w-4" />
                {aiChatOpen ? "Hide AI Chat" : "Show AI Chat"}
              </Button>
            </div>
          )}
        </aside>

        {/* Center Panel - Editor */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Section Header */}
          <div className="flex items-center justify-between px-8 py-4 border-b bg-background/50">
            <div>
              <h2 className="text-2xl font-bold capitalize">
                {activeSection.replace("-", " ")}
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                {SECTIONS.find((s) => s.id === activeSection)?.label}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setActiveTab("preview")}
                className="gap-2"
              >
                <Eye className="h-4 w-4" />
                Preview
              </Button>
            </div>
          </div>

          {/* Editor Content */}
          <ScrollArea className="flex-1">
            <div className="p-8">
              <Card className="max-w-4xl mx-auto p-8 shadow-xl">
                {activeSection === "personal" && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold border-b pb-3">
                      Personal Information
                    </h3>
                    
                    {/* Photo Upload */}
                    <div className="flex items-center gap-6">
                      <div className="relative">
                        <Avatar className="h-24 w-24 border-4 border-primary/10">
                          <AvatarImage src={resumeData.personalInfo.photo} />
                          <AvatarFallback className="text-2xl bg-gradient-to-br from-primary/20 to-secondary/20">
                            {getInitials(resumeData.personalInfo.fullName || "Your Name")}
                          </AvatarFallback>
                        </Avatar>
                        <Button
                          variant="outline"
                          size="sm"
                          className="absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-full text-xs"
                        >
                          Upload
                        </Button>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-muted-foreground">
                          Upload a professional headshot (optional)
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Recommended: 300x400px, JPG or PNG
                        </p>
                      </div>
                    </div>

                    <Separator />

                    {/* Form Fields */}
                    <div className="grid gap-6 md:grid-cols-2">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Full Name *</label>
                        <Input
                          value={resumeData.personalInfo.fullName}
                          onChange={(e) => updatePersonalInfo("fullName", e.target.value)}
                          placeholder="John Doe"
                          className="h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Professional Title</label>
                        <Input
                          value={resumeData.personalInfo.title}
                          onChange={(e) => updatePersonalInfo("title", e.target.value)}
                          placeholder="Senior Software Engineer"
                          className="h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Email *</label>
                        <Input
                          type="email"
                          value={resumeData.personalInfo.email}
                          onChange={(e) => updatePersonalInfo("email", e.target.value)}
                          placeholder="john@example.com"
                          className="h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Phone</label>
                        <Input
                          type="tel"
                          value={resumeData.personalInfo.phone}
                          onChange={(e) => updatePersonalInfo("phone", e.target.value)}
                          placeholder="+1 (555) 000-0000"
                          className="h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Location</label>
                        <Input
                          value={resumeData.personalInfo.location}
                          onChange={(e) => updatePersonalInfo("location", e.target.value)}
                          placeholder="San Francisco, CA"
                          className="h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Website</label>
                        <Input
                          value={resumeData.personalInfo.website}
                          onChange={(e) => updatePersonalInfo("website", e.target.value)}
                          placeholder="johndoe.com"
                          className="h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">LinkedIn</label>
                        <Input
                          value={resumeData.personalInfo.linkedin}
                          onChange={(e) => updatePersonalInfo("linkedin", e.target.value)}
                          placeholder="linkedin.com/in/johndoe"
                          className="h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">GitHub</label>
                        <Input
                          value={resumeData.personalInfo.github}
                          onChange={(e) => updatePersonalInfo("github", e.target.value)}
                          placeholder="github.com/johndoe"
                          className="h-11"
                        />
                      </div>
                    </div>

                    {/* Professional Summary */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Professional Summary</label>
                      <textarea
                        value={resumeData.personalInfo.summary}
                        onChange={(e) => updatePersonalInfo("summary", e.target.value)}
                        placeholder="Write a compelling professional summary that highlights your experience, skills, and career objectives..."
                        className="w-full rounded-lg border bg-background px-4 py-3 min-h-[150px] resize-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        rows={6}
                      />
                      <p className="text-xs text-muted-foreground">
                        {resumeData.personalInfo.summary.length} characters • ~
                        {Math.ceil(resumeData.personalInfo.summary.split(" ").length)} words
                      </p>
                    </div>
                  </div>
                )}

                {activeSection === "experience" && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold">Work Experience</h3>
                      <Button onClick={() => {}} className="gap-2">
                        <Plus className="h-4 w-4" />
                        Add Experience
                      </Button>
                    </div>
                    <div className="text-center py-12 text-muted-foreground border-2 border-dashed rounded-lg">
                      <Briefcase className="h-12 w-12 mx-auto mb-4 opacity-20" />
                      <p className="font-medium">No work experience added yet</p>
                      <p className="text-sm mt-2">
                        Add your first work experience to showcase your career
                      </p>
                    </div>
                  </div>
                )}

                {activeSection === "education" && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold">Education</h3>
                      <Button onClick={() => {}} className="gap-2">
                        <Plus className="h-4 w-4" />
                        Add Education
                      </Button>
                    </div>
                    <div className="text-center py-12 text-muted-foreground border-2 border-dashed rounded-lg">
                      <GraduationCap className="h-12 w-12 mx-auto mb-4 opacity-20" />
                      <p className="font-medium">No education added yet</p>
                      <p className="text-sm mt-2">
                        Add your educational qualifications
                      </p>
                    </div>
                  </div>
                )}

                {activeSection === "skills" && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold">Skills</h3>
                      <Button onClick={() => {}} className="gap-2">
                        <Plus className="h-4 w-4" />
                        Add Skill
                      </Button>
                    </div>
                    <div className="text-center py-12 text-muted-foreground border-2 border-dashed rounded-lg">
                      <Lightbulb className="h-12 w-12 mx-auto mb-4 opacity-20" />
                      <p className="font-medium">No skills added yet</p>
                      <p className="text-sm mt-2">
                        Add your technical and soft skills
                      </p>
                    </div>
                  </div>
                )}

                {activeSection === "projects" && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold">Projects</h3>
                      <Button onClick={() => {}} className="gap-2">
                        <Plus className="h-4 w-4" />
                        Add Project
                      </Button>
                    </div>
                    <div className="text-center py-12 text-muted-foreground border-2 border-dashed rounded-lg">
                      <FolderOpen className="h-12 w-12 mx-auto mb-4 opacity-20" />
                      <p className="font-medium">No projects added yet</p>
                      <p className="text-sm mt-2">
                        Showcase your best work and portfolio
                      </p>
                    </div>
                  </div>
                )}

                {["certifications", "languages", "references"].includes(activeSection) && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold capitalize">
                        {activeSection}
                      </h3>
                      <Button onClick={() => {}} className="gap-2">
                        <Plus className="h-4 w-4" />
                        Add {activeSection.slice(0, -1)}
                      </Button>
                    </div>
                    <div className="text-center py-12 text-muted-foreground border-2 border-dashed rounded-lg">
                      <p className="font-medium">
                        No {activeSection} added yet
                      </p>
                      <p className="text-sm mt-2">
                        Add your {activeSection.slice(0, -1)} information
                      </p>
                    </div>
                  </div>
                )}
              </Card>
            </div>
          </ScrollArea>
        </main>

        {/* Right Panel - Preview & AI Chat */}
        <aside
          className={cn(
            "flex flex-col border-l bg-card/30 backdrop-blur-sm transition-all duration-300",
            rightPanelOpen ? "w-[450px]" : "w-16"
          )}
        >
          {/* Panel Header */}
          <div className="flex items-center justify-between p-4 border-b">
            {rightPanelOpen && (
              <h2 className="font-semibold">Preview & AI</h2>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setRightPanelOpen(!rightPanelOpen)}
              className="ml-auto"
            >
              {rightPanelOpen ? (
                <ChevronRight className="h-4 w-4" />
              ) : (
                <ChevronLeft className="h-4 w-4" />
              )}
            </Button>
          </div>

          {rightPanelOpen && (
            <>
              {/* Tab Switcher */}
              <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="flex-1 flex flex-col">
                <div className="px-4 pt-4">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="preview" className="gap-2">
                      <Eye className="h-4 w-4" />
                      Preview
                    </TabsTrigger>
                    <TabsTrigger value="ai" className="gap-2 relative">
                      <Brain className="h-4 w-4" />
                      AI Chat
                      {aiChatOpen && (
                        <span className="absolute -top-1 -right-1 h-2 w-2 bg-primary rounded-full animate-pulse" />
                      )}
                    </TabsTrigger>
                  </TabsList>
                </div>

                <div className="flex-1 overflow-hidden">
                  <TabsContent value="preview" className="h-full mt-0">
                    <ScrollArea className="h-full">
                      <div className="p-4">
                        {/* Resume Preview Component */}
                        <Card className="overflow-hidden border shadow-lg">
                          <div className="bg-gradient-to-r from-primary/5 to-secondary/5 p-4 border-b flex items-center justify-between">
                            <span className="text-xs font-medium text-muted-foreground">
                              Live Preview
                            </span>
                            <div className="flex gap-2">
                              <Button variant="ghost" size="sm" className="h-8">
                                <Settings className="h-3 w-3" />
                              </Button>
                              <PDFExportButton data={resumeData}>
                                <Button variant="ghost" size="sm" className="h-8">
                                  <Download className="h-3 w-3" />
                                </Button>
                              </PDFExportButton>
                            </div>
                          </div>
                          <div className="p-6 min-h-[500px]">
                            {/* Resume preview content */}
                            {resumeData.personalInfo.fullName ? (
                              <div className="space-y-6">
                                {/* Header */}
                                <div className="text-center border-b pb-4">
                                  <h1 className="text-3xl font-bold">
                                    {resumeData.personalInfo.fullName}
                                  </h1>
                                  <p className="text-lg text-muted-foreground mt-1">
                                    {resumeData.personalInfo.title}
                                  </p>
                                  <div className="flex justify-center gap-4 mt-3 text-sm text-muted-foreground">
                                    {resumeData.personalInfo.email && (
                                      <span>{resumeData.personalInfo.email}</span>
                                    )}
                                    {resumeData.personalInfo.phone && (
                                      <span>{resumeData.personalInfo.phone}</span>
                                    )}
                                    {resumeData.personalInfo.location && (
                                      <span>{resumeData.personalInfo.location}</span>
                                    )}
                                  </div>
                                </div>

                                {/* Summary */}
                                {resumeData.personalInfo.summary && (
                                  <section>
                                    <h2 className="text-lg font-semibold uppercase tracking-wider text-primary mb-2">
                                      Summary
                                    </h2>
                                    <p className="text-sm leading-relaxed">
                                      {resumeData.personalInfo.summary}
                                    </p>
                                  </section>
                                )}

                                {/* Experience Preview */}
                                {resumeData.experience.length > 0 && (
                                  <section>
                                    <h2 className="text-lg font-semibold uppercase tracking-wider text-primary mb-3">
                                      Experience
                                    </h2>
                                    <div className="space-y-3">
                                      {resumeData.experience.slice(0, 2).map((exp: any) => (
                                        <div key={exp.id} className="text-sm">
                                          <div className="font-medium">{exp.position}</div>
                                          <div className="text-muted-foreground">
                                            {exp.company} • {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                                          </div>
                                        </div>
                                      ))}
                                      {resumeData.experience.length > 2 && (
                                        <p className="text-xs text-muted-foreground">
                                          +{resumeData.experience.length - 2} more...
                                        </p>
                                      )}
                                    </div>
                                  </section>
                                )}
                              </div>
                            ) : (
                              <div className="text-center py-20 text-muted-foreground">
                                <FileText className="h-16 w-16 mx-auto mb-4 opacity-20" />
                                <p className="font-medium">Your resume preview</p>
                                <p className="text-sm mt-2">
                                  Fill in your information to see the preview
                                </p>
                              </div>
                            )}
                          </div>
                        </Card>
                      </div>
                    </ScrollArea>
                  </TabsContent>

                  <TabsContent value="ai" className="h-full mt-0">
                    <AIChat resumeId={currentResume?.id || ""} />
                  </TabsContent>
                </div>
              </Tabs>
            </>
          )}
        </aside>
      </div>

      {/* Template Selector Modal */}
      {showTemplates && (
        <TemplateSelector
          selectedTemplate={resumeData.personalInfo.photo || "modern"}
          onTemplateSelect={(template) => {
            // Update resume template
            setShowTemplates(false);
          }}
          onClose={() => setShowTemplates(false)}
        />
      )}
    </div>
  );
}
