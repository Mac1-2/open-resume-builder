import {create} from 'zustand';
import {devtools} from 'zustand/middleware';
import {type ResumeData} from '@/components/resume/ResumeEditor';

interface ResumeStore {
  resumes: ResumeData[];
  currentResume: ResumeData | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setCurrentResume: (resume: ResumeData | null) => void;
  addResume: (resume: ResumeData) => void;
  createResume: (resume: ResumeData) => void;
  updateResume: (id: string, data: Partial<ResumeData>) => void;
  deleteResume: (id: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

export const useResumeStore = create<ResumeStore>()(
  devtools(
    (set) => ({
      resumes: [],
      currentResume: null,
      isLoading: false,
      error: null,

      setCurrentResume: (resume) => set({currentResume: resume}),
      addResume: (resume) =>
        set((state) => ({
          resumes: [...state.resumes, resume],
          currentResume: resume,
        })),
      createResume: (resume: ResumeData) =>
        set((state) => ({
          resumes: [...state.resumes, resume],
          currentResume: resume,
        })),
      updateResume: (id, data) =>
        set((state) => ({
          resumes: state.resumes.map((resume) =>
            resume?.personalInfo?.fullName === id // Simple ID matching for demo
              ? {...resume, ...data}
              : resume
          ),
          currentResume:
            state.currentResume?.personalInfo?.fullName === id
              ? {...state.currentResume, ...data}
              : state.currentResume,
        })),
      deleteResume: (id) =>
        set((state) => ({
          resumes: state.resumes.filter(
            (resume) => resume?.personalInfo?.fullName !== id
          ),
          currentResume:
            state.currentResume?.personalInfo?.fullName === id
              ? null
              : state.currentResume,
        })),
      setLoading: (loading) => set({isLoading: loading}),
      setError: (error) => set({error}),
    }),
    {
      name: 'resume-store',
    }
  )
);