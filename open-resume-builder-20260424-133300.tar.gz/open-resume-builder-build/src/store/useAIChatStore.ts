import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { type ChatMessage } from '@/components/ai/AIChat';
import { prisma } from '@/lib/db';
import { type Resume, type AIChat as AIChatModel } from '@prisma/client';

export interface Suggestion {
  id: string;
  type: 'insert' | 'replace' | 'delete' | 'suggest';
  section: string;
  field?: string;
  currentContent?: string;
  suggestedContent: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
}

export interface ChatWithMessages {
  id: string;
  resumeId?: string | null;
  userId?: string | null;
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
}

interface AIChatStore {
  chats: ChatWithMessages[];
  currentChatId: string | null;
  isLoading: boolean;
  error: string | null;
  activeSuggestions: Suggestion[];
  currentResumeId: string | null;

  // Actions
  createChat: (resumeId?: string) => Promise<void>;
  setCurrentChat: (chatId: string | null) => void;
  addMessage: (chatId: string, message: Omit<ChatMessage, 'id' | 'timestamp'>) => Promise<void>;
  loadChats: (userId?: string, resumeId?: string) => Promise<void>;
  clearChats: () => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  setResumeContext: (resumeId: string | null) => void;
  addSuggestion: (suggestion: Suggestion) => void;
  removeSuggestion: (id: string) => void;
  clearSuggestions: () => void;
}

export const useAIChatStore = create<AIChatStore>()(
  devtools(
    (set, get) => ({
      chats: [],
      currentChatId: null,
      isLoading: false,
      error: null,
      activeSuggestions: [],
      currentResumeId: null,

      createChat: async (resumeId?: string) => {
        try {
          const dbChat = await prisma.aIChat.create({
            data: {
              resumeId,
              messages: [],
            },
          });

          const newChat: ChatWithMessages = {
            id: dbChat.id,
            resumeId: dbChat.resumeId,
            messages: [],
            createdAt: dbChat.createdAt,
            updatedAt: dbChat.updatedAt,
          };

          set((state) => ({
            chats: [newChat, ...state.chats],
            currentChatId: newChat.id,
            currentResumeId: resumeId || null,
          }));
        } catch (error) {
          console.error('Error creating chat:', error);
          const localId = crypto.randomUUID();
          const newChat: ChatWithMessages = {
            id: localId,
            resumeId,
            messages: [],
            createdAt: new Date(),
            updatedAt: new Date(),
          };
          set((state) => ({
            chats: [newChat, ...state.chats],
            currentChatId: localId,
            currentResumeId: resumeId || null,
          }));
        }
      },

      setCurrentChat: (chatId) => set({ currentChatId: chatId }),

      addMessage: async (chatId, messageData) => {
        const message: ChatMessage = {
          ...messageData,
          id: crypto.randomUUID(),
          timestamp: new Date(),
        };

        set((state) => ({
          chats: state.chats.map((chat) =>
            chat.id === chatId
              ? {
                  ...chat,
                  messages: [...chat.messages, message],
                  updatedAt: new Date(),
                }
              : chat
          ),
        }));

        try {
          const chat = get().chats.find((c) => c.id === chatId);
          if (chat) {
             const updatedMessages = [...chat.messages, message];
             await prisma.aIChat.update({
               where: { id: chatId },
               data: { messages: updatedMessages as any },
             });
          }
        } catch (error) {
          console.error('Error saving message:', error);
        }
      },

      loadChats: async (userId?: string, resumeId?: string) => {
        try {
          const where: any = {};
          if (userId) where.userId = userId;
          if (resumeId) where.resumeId = resumeId;

          const dbChats = await prisma.aIChat.findMany({
            where,
            orderBy: { updatedAt: 'desc' },
          });

          const loadedChats: ChatWithMessages[] = dbChats.map((chat) => ({
            id: chat.id,
            resumeId: chat.resumeId,
            userId: chat.userId,
            messages: (chat.messages as unknown) as ChatMessage[],
            createdAt: chat.createdAt,
            updatedAt: chat.updatedAt,
          }));

          set({ chats: loadedChats });
        } catch (error) {
          console.error('Error loading chats:', error);
          set({ error: 'Failed to load chats' });
        }
      },

      clearChats: () => set({ chats: [], currentChatId: null, error: null }),

      setLoading: (isLoading) => set({ isLoading }),

      setError: (error) => set({ error }),

      setResumeContext: (resumeId) => set({ currentResumeId: resumeId }),

      addSuggestion: (suggestion) =>
        set((state) => ({
          activeSuggestions: [...state.activeSuggestions, suggestion],
        })),

      removeSuggestion: (id) =>
        set((state) => ({
          activeSuggestions: state.activeSuggestions.filter((s) => s.id !== id),
        })),

      clearSuggestions: () => set({ activeSuggestions: [] }),
    }),
    {
      name: 'ai-chat-store',
    }
  )
);