import {PrismaClient} from '@prisma/client';

declare global {
  // eslint-disable-next-line no-var
  var cachedPrisma: PrismaClient;
}

let prisma: PrismaClient;

if (process.env.NODE_ENV === 'production') {
  prisma = new PrismaClient();
} else {
  if (!global.cachedPrisma) {
    global.cachedPrisma = new PrismaClient();
  }
  prisma = global.cachedPrisma;
}

export {prisma};

// Type exports for convenience
export type {
  User,
  Resume,
  Template,
  AIChat,
  Settings,
} from '@prisma/client';

// Database helper functions
export const getResumesByUser = async (userId: string) => {
  return prisma.resume.findMany({
    where: {userId},
    orderBy: {updatedAt: 'desc'},
  });
};

export const getResumeById = async (id: string, userId?: string) => {
  return prisma.resume.findFirst({
    where: {
      id,
      ...(userId ? {userId} : {}),
    },
  });
};

export const createResume = async (data: {
  userId: string;
  title: string;
  template: string;
  data?: any;
}) => {
  return prisma.resume.create({
    data: {
      ...data,
      data: data.data || {},
    },
  });
};

export const updateResume = async (id: string, data: any) => {
  return prisma.resume.update({
    where: {id},
    data,
  });
};

export const deleteResume = async (id: string) => {
  return prisma.resume.delete({
    where: {id},
  });
};

export const getActiveTemplates = async () => {
  return prisma.template.findMany({
    where: {isActive: true},
    orderBy: {createdAt: 'desc'},
  });
};

export const getChatHistory = async (resumeId: string) => {
  return prisma.aIChat.findMany({
    where: { resumeId },
    orderBy: { createdAt: 'asc' },
  });
};

export const createChat = async (data: {
  resumeId?: string;
  userId?: string;
  messages: any;
}) => {
  return prisma.aIChat.create({
    data: {
      ...data,
    },
  });
};