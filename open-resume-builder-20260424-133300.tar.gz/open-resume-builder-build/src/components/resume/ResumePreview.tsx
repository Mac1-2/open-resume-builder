"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import {
  FileText,
  Download,
  Printer,
  Share2,
  Eye,
  Edit,
  Palette,
  LayoutGrid,
  Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";

// Import template components
import ProfessionalExecutive from "./templates/ProfessionalExecutive";
import ModernClean from "./templates/ModernClean";
import CreativeBold from "./templates/CreativeBold";
import MinimalSwiss from "./templates/MinimalSwiss";
import TechDeveloper from "./templates/TechDeveloper";

interface ResumeData {
  personalInfo: {
    fullName: string;
    title: string;
    email?: string;
    phone?: string;
    location?: string;
    website?: string;
    summary?: string;
  };
  experience: Array<{
    position: string;
    company: string;
    startDate: string;
    endDate?: string;
    current?: boolean;
    description?: string;
    achievements?: string[];
  }>;
  education: Array<{
    degree: string;
    institution: string;
    field?: string;
    startDate: string;
    endDate: string;
  }>;
  skills: Array<{
    category: string;
    items: string[];
  }>;
  projects: Array<{
    name: string;
    description: string;
    url?: string;
    technologies?: string[];
  }>;
  certifications: Array<{
    name: string;
    issuer: string;
    date: string;
  }>;
  languages: Array<{
    language: string;
    proficiency: string;
  }>;
}

interface ResumePreviewProps {
  data: ResumeData;
  template?: string;
  className?: string;
}

// Sample data for preview
const sampleData: ResumeData = {
  personalInfo: {
    fullName: "Alex Johnson",
    title: "Senior Software Engineer",
    email: "alex.johnson@email.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    website: "https://alexjohnson.dev",
    summary: "Experienced software engineer with 8+ years of expertise in full-stack development, specializing in React, Node.js, and cloud architectures. Passionate about building scalable applications and mentoring junior developers.",
  },
  experience: [
    {
      position: "Senior Software Engineer",
      company: "Tech Innovations Inc.",
      startDate: "Jan 2020",
      current: true,
      description: "Lead development of microservices-based platform serving 1M+ users. Architected scalable solutions using AWS, Docker, and Kubernetes.",
      achievements: [
        "Improved system performance by 40% through optimization and caching strategies",
        "Mentored 5 junior developers, improving team productivity by 25%",
        "Reduced deployment time from hours to minutes with CI/CD pipeline implementation",
      ],
    },
    {
      position: "Software Engineer",
      company: "WebSolutions Corp",
      startDate: "Mar 2017",
      endDate: "Dec 2019",
      description: "Developed responsive web applications using React and Redux. Collaborated with cross-functional teams to deliver features on schedule.",
      achievements: [
        "Built e-commerce platform processing $2M+ in annual transactions",
        "Implemented automated testing suite increasing code coverage to 90%",
        "Optimized database queries reducing load times by 60%",
      ],
    },
  ],
  education: [
    {
      degree: "Bachelor of Science in Computer Science",
      institution: "University of California, Berkeley",
      field: "Software Engineering",
      startDate: "Sep 2012",
      endDate: "May 2016",
    },
  ],
  skills: [
    {
      category: "Programming Languages",
      items: ["JavaScript/TypeScript", "Python", "Java", "C++"],
    },
    {
      category: "Frontend Technologies",
      items: ["React", "Vue.js", "HTML5", "CSS3", "Tailwind CSS"],
    },
    {
      category: "Backend & Database",
      items: ["Node.js", "Express", "PostgreSQL", "MongoDB", "Redis"],
    },
    {
      category: "DevOps & Cloud",
      items: ["AWS", "Docker", "Kubernetes", "Jenkins", "Git"],
    },
  ],
  projects: [
    {
      name: "TaskFlow Pro",
      description: "Enterprise task management application with real-time collaboration features",
      url: "https://taskflowpro.com",
      technologies: ["React", "Node.js", "PostgreSQL", "WebSocket"],
    },
    {
      name: "CloudCost Optimizer",
      description: "AI-powered tool for analyzing and reducing cloud infrastructure costs",
      url: "https://cloudcostopt.dev",
      technologies: ["Python", "Machine Learning", "AWS Lambda", "Terraform"],
    },
  ],
  certifications: [
    {
      name: "AWS Certified Solutions Architect",
      issuer: "Amazon Web Services",
      date: "2021",
    },
    {
      name: "Google Cloud Professional Developer",
      issuer: "Google Cloud",
      date: "2020",
    },
  ],
  languages: [
    {
      language: "English",
      proficiency: "Native",
    },
    {
      language: "Spanish",
      proficiency: "Fluent",
    },
  ],
};

const TemplateComponents: Record<
  string,
  React.ComponentType<{ data: ResumeData; className?: string }>
> = {
  professional: ProfessionalExecutive,
  modern: ModernClean,
  creative: CreativeBold,
  minimal: MinimalSwiss,
  tech: TechDeveloper,
};

export default function ResumePreview({
  data = sampleData,
  template = "modern",
  className,
}: ResumePreviewProps) {
  const [isPrintView, setIsPrintView] = useState(false);
  const [viewSize, setViewSize] = useState<"desktop" | "mobile">("desktop");
  const TemplateComponent = TemplateComponents[template] || ModernClean;

  const handlePrint = () => {
    setIsPrintView(true);
    // Trigger print dialog after a short delay to ensure print styles are applied
    setTimeout(() => {
      window.print();
      setIsPrintView(false);
    }, 500);
  };

  const handleDownload = () => {
    // TODO: Implement PDF download using html2canvas + pdf-lib
    console.log("Downloading PDF...");
  };

  const handleShare = () => {
    // TODO: Implement share functionality
    console.log("Sharing resume...");
  };

  const toggleViewSize = () => {
    setViewSize(viewSize === "desktop" ? "mobile" : "desktop");
  };

  return (
    <Card className={cn("relative overflow-hidden", className)}>
      {/* Preview Header */}
      <div className={cn(
        "flex items-center justify-between border-b bg-muted/50 px-6 py-4",
        isPrintView && "hidden"
      )}>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <FileText className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold">Resume Preview</h3>
            <p className="text-xs text-muted-foreground">
              {template.charAt(0).toUpperCase() + template.slice(1)} Template
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={handlePrint}>
            <Printer className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={handleDownload}>
            <Download className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={handleShare}>
            <Share2 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={toggleViewSize}>
            {viewSize === "desktop" ? (
              <LayoutGrid className="h-4 w-4" />
            ) : (
              <Info className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>

      {/* Preview Content */}
      <div className={cn(
        "p-8",
        isPrintView && "p-4"
      )}>
        <div className={cn(
          "mx-auto max-w-4xl",
          viewSize === "mobile" && "w-full"
        )}>
          {/* Render the selected template component */}
          <TemplateComponent data={data} className="min-h-[800px]" />
        </div>
      </div>
    </Card>
  );
}