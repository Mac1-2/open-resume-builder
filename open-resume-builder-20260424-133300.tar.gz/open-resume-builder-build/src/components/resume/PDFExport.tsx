"use client";

import React, { useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { useResumeStore } from "@/store/useResumeStore";
import { cn } from "@/lib/utils";
import html2canvas from "html2canvas";
import { PDFDocument } from "pdf-lib";

interface PDFExportProps {
  className?: string;
  children?: React.ReactNode;
  data?: any; // Optional resume data override
}

export function PDFExport({ className, children, data }: PDFExportProps) {
  const storeResume = useResumeStore((state) => state.currentResume);
  const currentResume = data || storeResume;
  const exportRef = useRef<HTMLDivElement>(null);

  const handleExport = useCallback(async () => {
    if (!currentResume || !exportRef.current) {
      console.error("No resume data or export element found");
      return;
    }

    try {
      // Show loading state if needed
      const button = document.activeElement as HTMLButtonElement;
      const originalText = button?.innerText;
      if (button) button.innerText = "Generating PDF...";

      // Get the resume preview element
      const resumeElement = exportRef.current;

      // Calculate dimensions for A4 page
      const a4Width = 794; // 210mm at 96 DPI
      const a4Height = 1123; // 297mm at 96 DPI

      // Capture the resume as canvas with high quality
      const canvas = await html2canvas(resumeElement, {
        scale: 2, // Higher scale for better quality
        useCORS: true,
        allowTaint: true,
        backgroundColor: "#ffffff",
        logging: false,
        width: a4Width,
        height: a4Height,
        windowWidth: a4Width,
        windowHeight: a4Height,
      });

      // Get image data from canvas
      const imgData = canvas.toDataURL("image/jpeg", 0.95);

      // Create a new PDF document
      const pdfDoc = await PDFDocument.create();
      const page = pdfDoc.addPage([a4Width, a4Height]);

      // Embed the image into the PDF
      const jpgImage = await pdfDoc.embedJpg(imgData);

      // Draw the image to fill the entire page
      const { width, height } = page.getSize();
      page.drawImage(jpgImage, {
        x: 0,
        y: 0,
        width: width,
        height: height,
      });

      // Serialize the PDF to bytes
      const pdfBytes = await pdfDoc.save();

      // Create blob and download
      const blob = new Blob([pdfBytes as BlobPart], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${currentResume.personalInfo?.fullName?.replace(/\s+/g, "_") || "resume"}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      // Restore button text
      if (button) button.innerText = originalText || "Export PDF";
    } catch (error) {
      console.error("Error exporting PDF:", error);
      alert("Failed to export PDF. Please try again.");
    }
  }, [currentResume]);

  if (!currentResume) {
    return (
      <Button variant="outline" disabled className={className}>
        No Resume to Export
      </Button>
    );
  }

  if (children && React.isValidElement(children)) {
    return React.cloneElement(children as any, {
      onClick: handleExport,
    });
  }

  return (
    <div className={cn("space-y-4", className)}>
      <Button onClick={handleExport} className="w-full">
        Download PDF
      </Button>
      {/* Hidden container for PDF rendering */}
      <div
        ref={exportRef}
        className="hidden"
        style={{
          position: "absolute",
          left: "-9999px",
          top: "-9999px",
          width: "794px",
          height: "1123px",
        }}
      >
        <PDFPreviewContent data={currentResume} />
      </div>
    </div>
  );
}

// Internal component that renders the resume for PDF capture
function PDFPreviewContent({ data }: { data: any }) {
  // Use the first available template or default rendering
  // This will be overridden by the actual template being previewed
  return (
    <div
      style={{
        width: "794px",
        height: "1123px",
        backgroundColor: "white",
        padding: "40px",
        fontFamily: "Georgia, serif",
        color: "#1e293b",
      }}
    >
      {/* Header */}
      <div style={{ borderBottom: "2px solid #1e40af", paddingBottom: "20px", marginBottom: "30px" }}>
        <h1 style={{ fontSize: "32px", fontWeight: "bold", marginBottom: "8px", color: "#0f172a", fontFamily: "Georgia, serif" }}>
          {data.personalInfo?.fullName || "Your Name"}
        </h1>
        <p style={{ fontSize: "18px", color: "#64748b", marginBottom: "12px" }}>
          {data.personalInfo?.title || ""}
        </p>
        <div style={{ fontSize: "12px", color: "#64748b", lineHeight: "1.8" }}>
          {data.personalInfo?.email && <span>{data.personalInfo.email} | </span>}
          {data.personalInfo?.phone && <span>{data.personalInfo.phone} | </span>}
          {data.personalInfo?.location && <span>{data.personalInfo.location}</span>}
        </div>
      </div>

      <div style={{ display: "flex", gap: "40px" }}>
        {/* Sidebar - 30% */}
        <div style={{ width: "30%", fontSize: "12px" }}>
          {/* Skills */}
          {data.skills && data.skills.length > 0 && (
            <div style={{ marginBottom: "24px" }}>
              <h2 style={{ fontSize: "14px", fontWeight: "bold", marginBottom: "12px", color: "#1e40af", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Skills
              </h2>
              {data.skills.map((skillCategory: any, idx: number) => (
                <div key={idx} style={{ marginBottom: "12px" }}>
                  <h3 style={{ fontSize: "11px", fontWeight: "bold", color: "#334155", marginBottom: "6px" }}>
                    {skillCategory.category}
                  </h3>
                  {skillCategory.items.map((skill: string, i: number) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", marginBottom: "4px" }}>
                      <div style={{ width: "6px", height: "6px", borderRadius: "50%", backgroundColor: "#1e40af", marginRight: "8px" }} />
                      <span style={{ fontSize: "11px", color: "#475569" }}>{skill}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}

          {/* Languages */}
          {data.languages && data.languages.length > 0 && (
            <div>
              <h2 style={{ fontSize: "14px", fontWeight: "bold", marginBottom: "12px", color: "#1e40af", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Languages
              </h2>
              {data.languages.map((lang: any, idx: number) => (
                <div key={idx} style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px", fontSize: "11px" }}>
                  <span>{lang.language}</span>
                  <span style={{ color: "#64748b" }}>{lang.proficiency}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Main Content - 70% */}
        <div style={{ width: "70%", fontSize: "12px" }}>
          {/* Summary */}
          {data.personalInfo?.summary && (
            <div style={{ marginBottom: "24px" }}>
              <h2 style={{ fontSize: "14px", fontWeight: "bold", marginBottom: "12px", color: "#1e40af", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Professional Summary
              </h2>
              <p style={{ fontSize: "12px", lineHeight: "1.6", color: "#334155" }}>
                {data.personalInfo.summary}
              </p>
            </div>
          )}

          {/* Experience */}
          {data.experience && data.experience.length > 0 && (
            <div style={{ marginBottom: "24px" }}>
              <h2 style={{ fontSize: "14px", fontWeight: "bold", marginBottom: "16px", color: "#1e40af", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Experience
              </h2>
              {data.experience.map((exp: any, idx: number) => (
                <div key={idx} style={{ marginBottom: "20px", borderLeft: "2px solid #1e40af", paddingLeft: "12px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                    <h3 style={{ fontSize: "13px", fontWeight: "bold", color: "#0f172a" }}>{exp.position}</h3>
                    <span style={{ fontSize: "11px", color: "#64748b" }}>
                      {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                    </span>
                  </div>
                  <p style={{ fontSize: "12px", fontWeight: "500", color: "#475569", marginBottom: "6px" }}>
                    {exp.company}
                  </p>
                  {exp.description && (
                    <p style={{ fontSize: "11px", lineHeight: "1.5", color: "#64748b", marginBottom: "6px" }}>
                      {exp.description}
                    </p>
                  )}
                  {exp.achievements && exp.achievements.length > 0 && (
                    <ul style={{ paddingLeft: "16px", fontSize: "11px", color: "#64748b" }}>
                      {exp.achievements.map((achievement: string, i: number) => (
                        <li key={i} style={{ marginBottom: "2px" }}>{achievement}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Education */}
          {data.education && data.education.length > 0 && (
            <div>
              <h2 style={{ fontSize: "14px", fontWeight: "bold", marginBottom: "16px", color: "#1e40af", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Education
              </h2>
              {data.education.map((edu: any, idx: number) => (
                <div key={idx} style={{ marginBottom: "12px" }}>
                  <h3 style={{ fontSize: "13px", fontWeight: "bold", color: "#0f172a" }}>{edu.degree}</h3>
                  <p style={{ fontSize: "11px", color: "#475569" }}>{edu.institution}</p>
                  {edu.field && (
                    <p style={{ fontSize: "10px", color: "#64748b", fontStyle: "italic" }}>{edu.field}</p>
                  )}
                  <p style={{ fontSize: "11px", color: "#64748b", marginTop: "2px" }}>
                    {edu.startDate} - {edu.endDate}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
