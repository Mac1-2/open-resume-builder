"use client";

import * as React from "react";
import {useState, useCallback} from "react";
import {Button} from "@/components/ui/button";
import {Card} from "@/components/ui/card";
import {Tabs, TabsContent, TabsList, TabsTrigger} from "@/components/ui/tabs";
import {ScrollArea} from "@/components/ui/scroll-area";
import {Separator} from "@/components/ui/separator";
import {cn} from "@/lib/utils";
import {
  FileText,
  Download,
  Share2,
  Save,
  Palette,
  Layout,
  Settings,
  Eye,
  Edit,
  Plus,
} from "lucide-react";

export interface ResumeData {
  id?: string; // Optional for new resumes
  template?: string; // Selected template ID
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    location: string;
    photo?: string;
    title?: string;
    summary: string;
    website?: string;
    linkedin?: string;
    github?: string;
  };
  experience: Array<{
    id: string;
    company: string;
    position: string;
    startDate: string;
    endDate: string;
    current: boolean;
    description: string;
    achievements: string[];
  }>;
  education: Array<{
    id: string;
    institution: string;
    degree: string;
    field: string;
    startDate: string;
    endDate: string;
    gpa?: string;
  }>;
  skills: Array<{
    category: string;
    items: string[];
  }>;
  projects: Array<{
    id: string;
    name: string;
    description: string;
    url?: string;
  }>;
  certifications: Array<{
    name: string;
    issuer: string;
    date: string;
  }>;
  languages: Array<{
    language: string;
    proficiency: string;
  }>;
}

interface ResumeEditorProps {
  resumeId?: string;
  initialData?: ResumeData;
  onSave?: (data: ResumeData) => void;
}

export default function ResumeEditor({
  resumeId,
  initialData,
  onSave,
}: ResumeEditorProps) {
  const [activeTab, setActiveTab] = useState("editor");
  const [resumeData, setResumeData] = useState<ResumeData>(
    initialData || getDefaultResumeData()
  );
  const [isSaving, setIsSaving] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  function getDefaultResumeData(): ResumeData {
    return {
      personalInfo: {
        fullName: "",
        email: "",
        phone: "",
        location: "",
        summary: "",
      },
      experience: [],
      education: [],
      skills: [],
      projects: [],
      certifications: [],
      languages: [],
    };
  }

  const handleSave = useCallback(async () => {
    setIsSaving(true);
    try {
      // TODO: Implement save logic
      if (onSave) {
        onSave(resumeData);
      }
      console.log("Resume saved:", resumeData);
    } catch (error) {
      console.error("Error saving resume:", error);
    } finally {
      setIsSaving(false);
    }
  }, [resumeData, onSave]);

  const handleExportPDF = useCallback(async () => {
    // TODO: Implement PDF export
    console.log("Exporting to PDF...");
  }, [resumeData]);

  const handleShare = useCallback(async () => {
    // TODO: Implement share functionality
    console.log("Sharing resume...");
  }, [resumeData]);

  const updatePersonalInfo = useCallback(
    (field: keyof ResumeData["personalInfo"], value: string) => {
      setResumeData((prev) => ({
        ...prev,
        personalInfo: {
          ...prev.personalInfo,
          [field]: value,
        },
      }));
    },
    []
  );

  const addExperience = useCallback(() => {
    const newExperience = {
      id: crypto.randomUUID(),
      company: "",
      position: "",
      startDate: "",
      endDate: "",
      current: false,
      description: "",
      achievements: [],
    };
    setResumeData((prev) => ({
      ...prev,
      experience: [...prev.experience, newExperience],
    }));
  }, []);

  const removeExperience = useCallback((id: string) => {
    setResumeData((prev) => ({
      ...prev,
      experience: prev.experience.filter((exp) => exp.id !== id),
    }));
  }, []);

  const updateExperience = useCallback(
    (id: string, field: string, value: any) => {
      setResumeData((prev) => ({
        ...prev,
        experience: prev.experience.map((exp) =>
          exp.id === id ? {...exp, [field]: value} : exp
        ),
      }));
    },
    []
  );

  const addEducation = useCallback(() => {
    const newEducation = {
      id: crypto.randomUUID(),
      institution: "",
      degree: "",
      field: "",
      startDate: "",
      endDate: "",
      gpa: "",
    };
    setResumeData((prev) => ({
      ...prev,
      education: [...prev.education, newEducation],
    }));
  }, []);

  const removeEducation = useCallback((id: string) => {
    setResumeData((prev) => ({
      ...prev,
      education: prev.education.filter((edu) => edu.id !== id),
    }));
  }, []);

  const addSkill = useCallback((category: string, skill: string) => {
    setResumeData((prev) => {
      const existingCategory = prev.skills.find(
        (s) => s.category === category
      );
      if (existingCategory) {
        return {
          ...prev,
          skills: prev.skills.map((s) =>
            s.category === category
              ? {...s, items: [...s.items, skill]}
              : s
          ),
        };
      }
      return {
        ...prev,
        skills: [...prev.skills, {category, items: [skill]}],
      };
    });
  }, []);

  const removeSkill = useCallback((category: string, skillIndex: number) => {
    setResumeData((prev) => ({
      ...prev,
      skills: prev.skills.map((s) =>
        s.category === category
          ? {...s, items: s.items.filter((_, i) => i !== skillIndex)}
          : s
      ),
    }));
  }, []);

  return (
    <div className="flex h-screen flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between border-b bg-card px-6 py-4">
        <div className="flex items-center gap-4">
          <FileText className="h-6 w-6 text-primary" />
          <h1 className="text-xl font-semibold">Resume Editor</h1>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleShare}>
            <Share2 className="mr-2 h-4 w-4" />
            Share
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowPreview(!showPreview)}>
            <Eye className="mr-2 h-4 w-4" />
            {showPreview ? "Hide Preview" : "Preview"}
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportPDF}>
            <Download className="mr-2 h-4 w-4" />
            Export PDF
          </Button>
          <Button size="sm" onClick={handleSave} disabled={isSaving}>
            <Save className="mr-2 h-4 w-4" />
            {isSaving ? "Saving..." : "Save"}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {showPreview ? (
          <div className="flex-1 overflow-auto p-6">
            <Card className="mx-auto max-w-4xl">
              {/* Preview content would go here */}
              <div className="p-8">
                <h2 className="text-center text-2xl font-bold">
                  {resumeData.personalInfo.fullName || "Your Name"}
                </h2>
                <p className="text-center text-muted-foreground">
                  {resumeData.personalInfo.email} | {resumeData.personalInfo.phone}
                </p>
                <Separator className="my-6" />
                <div className="space-y-4">
                  <section>
                    <h3 className="text-lg font-semibold">Summary</h3>
                    <p className="mt-2 text-sm text-muted-foreground">
                      {resumeData.personalInfo.summary || "No summary provided"}
                    </p>
                  </section>
                  {resumeData.experience.length > 0 && (
                    <section>
                      <h3 className="text-lg font-semibold">Experience</h3>
                      <div className="mt-4 space-y-4">
                        {resumeData.experience.map((exp) => (
                          <div key={exp.id}>
                            <h4 className="font-medium">{exp.position}</h4>
                            <p className="text-sm text-muted-foreground">
                              {exp.company} | {exp.startDate} -{" "}
                              {exp.current ? "Present" : exp.endDate}
                            </p>
                            <p className="mt-1 text-sm">{exp.description}</p>
                          </div>
                        ))}
                      </div>
                    </section>
                  )}
                </div>
              </div>
            </Card>
          </div>
        ) : (
          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            className="flex flex-1"
          >
            <div className="w-80 border-r bg-muted/50">
              <TabsList className="grid h-full w-full grid-cols-1 rounded-none border-b-0 p-2">
                <TabsTrigger
                  value="personal"
                  className="data-[state=active]:bg-background"
                >
                  Personal Info
                </TabsTrigger>
                <TabsTrigger
                  value="experience"
                  className="data-[state=active]:bg-background"
                >
                  Experience
                </TabsTrigger>
                <TabsTrigger
                  value="education"
                  className="data-[state=active]:bg-background"
                >
                  Education
                </TabsTrigger>
                <TabsTrigger
                  value="skills"
                  className="data-[state=active]:bg-background"
                >
                  Skills
                </TabsTrigger>
                <TabsTrigger
                  value="projects"
                  className="data-[state=active]:bg-background"
                >
                  Projects
                </TabsTrigger>
                <TabsTrigger
                  value="additional"
                  className="data-[state=active]:bg-background"
                >
                  Additional
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="flex-1 overflow-auto">
              <ScrollArea className="h-full">
                <div className="p-6">
                  <TabsContent value="personal" className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold mb-6">Personal Information</h2>
                      <div className="grid gap-6 md:grid-cols-2">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Full Name</label>
                          <input
                            type="text"
                            value={resumeData.personalInfo.fullName}
                            onChange={(e) =>
                              updatePersonalInfo("fullName", e.target.value)
                            }
                            className="w-full rounded-md border px-3 py-2"
                            placeholder="John Doe"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Email</label>
                          <input
                            type="email"
                            value={resumeData.personalInfo.email}
                            onChange={(e) =>
                              updatePersonalInfo("email", e.target.value)
                            }
                            className="w-full rounded-md border px-3 py-2"
                            placeholder="john@example.com"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Phone</label>
                          <input
                            type="tel"
                            value={resumeData.personalInfo.phone}
                            onChange={(e) =>
                              updatePersonalInfo("phone", e.target.value)
                            }
                            className="w-full rounded-md border px-3 py-2"
                            placeholder="+1 (555) 000-0000"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Location</label>
                          <input
                            type="text"
                            value={resumeData.personalInfo.location}
                            onChange={(e) =>
                              updatePersonalInfo("location", e.target.value)
                            }
                            className="w-full rounded-md border px-3 py-2"
                            placeholder="New York, NY"
                          />
                        </div>
                        <div className="md:col-span-2 space-y-2">
                          <label className="text-sm font-medium">Professional Summary</label>
                          <textarea
                            value={resumeData.personalInfo.summary}
                            onChange={(e) =>
                              updatePersonalInfo("summary", e.target.value)
                            }
                            className="w-full rounded-md border px-3 py-2"
                            rows={4}
                            placeholder="A brief professional summary..."
                          />
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="experience" className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-2xl font-bold">Work Experience</h2>
                      <Button onClick={addExperience}>
                        <Plus className="mr-2 h-4 w-4" />
                        Add Experience
                      </Button>
                    </div>
                    <div className="space-y-6">
                      {resumeData.experience.map((exp) => (
                        <Card key={exp.id} className="p-6">
                          <div className="grid gap-4 md:grid-cols-2">
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Position</label>
                              <input
                                type="text"
                                value={exp.position}
                                onChange={(e) =>
                                  updateExperience(
                                    exp.id,
                                    "position",
                                    e.target.value
                                  )
                                }
                                className="w-full rounded-md border px-3 py-2"
                                placeholder="Senior Developer"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Company</label>
                              <input
                                type="text"
                                value={exp.company}
                                onChange={(e) =>
                                  updateExperience(
                                    exp.id,
                                    "company",
                                    e.target.value
                                  )
                                }
                                className="w-full rounded-md border px-3 py-2"
                                placeholder="Tech Corp"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Start Date</label>
                              <input
                                type="date"
                                value={exp.startDate}
                                onChange={(e) =>
                                  updateExperience(
                                    exp.id,
                                    "startDate",
                                    e.target.value
                                  )
                                }
                                className="w-full rounded-md border px-3 py-2"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-medium">End Date</label>
                              <input
                                type="date"
                                value={exp.endDate}
                                onChange={(e) =>
                                  updateExperience(
                                    exp.id,
                                    "endDate",
                                    e.target.value
                                  )
                                }
                                disabled={exp.current}
                                className="w-full rounded-md border px-3 py-2 disabled:bg-muted"
                              />
                            </div>
                            <div className="flex items-center gap-4 md:col-span-2">
                              <label className="flex items-center gap-2">
                                <input
                                  type="checkbox"
                                  checked={exp.current}
                                  onChange={(e) =>
                                    updateExperience(
                                      exp.id,
                                      "current",
                                      e.target.checked
                                    )
                                  }
                                  className="rounded border-gray-300"
                                />
                                <span className="text-sm font-medium">Currently working here</span>
                              </label>
                            </div>
                            <div className="md:col-span-2 space-y-2">
                              <label className="text-sm font-medium">Description</label>
                              <textarea
                                value={exp.description}
                                onChange={(e) =>
                                  updateExperience(
                                    exp.id,
                                    "description",
                                    e.target.value
                                  )
                                }
                                className="w-full rounded-md border px-3 py-2"
                                rows={3}
                                placeholder="Describe your role and responsibilities..."
                              />
                            </div>
                            <div className="flex justify-end md:col-span-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => removeExperience(exp.id)}
                              >
                                Remove
                              </Button>
                            </div>
                          </div>
                        </Card>
                      ))}
                      {resumeData.experience.length === 0 && (
                        <div className="text-center py-12 text-muted-foreground">
                          <p>No work experience added yet.</p>
                          <p className="text-sm">Add your first work experience to get started.</p>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="education" className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-2xl font-bold">Education</h2>
                      <Button onClick={addEducation}>
                        <Plus className="mr-2 h-4 w-4" />
                        Add Education
                      </Button>
                    </div>
                    <div className="space-y-6">
                      {resumeData.education.map((edu) => (
                        <Card key={edu.id} className="p-6">
                          <div className="grid gap-4 md:grid-cols-2">
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Institution</label>
                              <input
                                type="text"
                                value={edu.institution}
                                onChange={(e) => {
                                  const newEducation = [...resumeData.education];
                                  const index = newEducation.findIndex(
                                    (item) => item.id === edu.id
                                  );
                                  newEducation[index].institution =
                                    e.target.value;
                                  setResumeData((prev) => ({
                                    ...prev,
                                    education: newEducation,
                                  }));
                                }}
                                className="w-full rounded-md border px-3 py-2"
                                placeholder="University Name"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Degree</label>
                              <input
                                type="text"
                                value={edu.degree}
                                onChange={(e) => {
                                  const newEducation = [...resumeData.education];
                                  const index = newEducation.findIndex(
                                    (item) => item.id === edu.id
                                  );
                                  newEducation[index].degree = e.target.value;
                                  setResumeData((prev) => ({
                                    ...prev,
                                    education: newEducation,
                                  }));
                                }}
                                className="w-full rounded-md border px-3 py-2"
                                placeholder="Bachelor of Science"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Field of Study</label>
                              <input
                                type="text"
                                value={edu.field}
                                onChange={(e) => {
                                  const newEducation = [...resumeData.education];
                                  const index = newEducation.findIndex(
                                    (item) => item.id === edu.id
                                  );
                                  newEducation[index].field = e.target.value;
                                  setResumeData((prev) => ({
                                    ...prev,
                                    education: newEducation,
                                  }));
                                }}
                                className="w-full rounded-md border px-3 py-2"
                                placeholder="Computer Science"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-medium">GPA (Optional)</label>
                              <input
                                type="text"
                                value={edu.gpa}
                                onChange={(e) => {
                                  const newEducation = [...resumeData.education];
                                  const index = newEducation.findIndex(
                                    (item) => item.id === edu.id
                                  );
                                  newEducation[index].gpa = e.target.value;
                                  setResumeData((prev) => ({
                                    ...prev,
                                    education: newEducation,
                                  }));
                                }}
                                className="w-full rounded-md border px-3 py-2"
                                placeholder="3.8"
                              />
                            </div>
                            <div className="space-y-2 md:col-span-2">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <label className="text-sm font-medium">Start Date</label>
                                  <input
                                    type="date"
                                    value={edu.startDate}
                                    onChange={(e) => {
                                      const newEducation = [...resumeData.education];
                                      const index = newEducation.findIndex(
                                        (item) => item.id === edu.id
                                      );
                                      newEducation[index].startDate =
                                        e.target.value;
                                      setResumeData((prev) => ({
                                        ...prev,
                                        education: newEducation,
                                      }));
                                    }}
                                    className="w-full rounded-md border px-3 py-2"
                                  />
                                </div>
                                <div>
                                  <label className="text-sm font-medium">End Date</label>
                                  <input
                                    type="date"
                                    value={edu.endDate}
                                    onChange={(e) => {
                                      const newEducation = [...resumeData.education];
                                      const index = newEducation.findIndex(
                                        (item) => item.id === edu.id
                                      );
                                      newEducation[index].endDate =
                                        e.target.value;
                                      setResumeData((prev) => ({
                                        ...prev,
                                        education: newEducation,
                                      }));
                                    }}
                                    className="w-full rounded-md border px-3 py-2"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="flex justify-end md:col-span-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => removeEducation(edu.id)}
                              >
                                Remove
                              </Button>
                            </div>
                          </div>
                        </Card>
                      ))}
                      {resumeData.education.length === 0 && (
                        <div className="text-center py-12 text-muted-foreground">
                          <p>No education history added yet.</p>
                          <p className="text-sm">Add your education to showcase your qualifications.</p>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="skills" className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold mb-6">Skills</h2>
                      <div className="grid gap-6">
                        <div>
                          <label className="text-sm font-medium">Add Skill Category</label>
                          <div className="flex gap-2 mt-2">
                            <input
                              type="text"
                              placeholder="e.g., Technical Skills"
                              className="flex-1 rounded-md border px-3 py-2"
                              onKeyPress={(e) => {
                                if (e.key === "Enter") {
                                  // TODO: Add category
                                }
                              }}
                            />
                          </div>
                        </div>
                        {resumeData.skills.map((category) => (
                          <Card key={category.category} className="p-6">
                            <h3 className="text-lg font-semibold mb-4">
                              {category.category}
                            </h3>
                            <div className="flex flex-wrap gap-2 mb-4">
                              {category.items.map((skill, index) => (
                                <span
                                  key={index}
                                  className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm text-primary"
                                >
                                  {skill}
                                  <button
                                    onClick={() =>
                                      removeSkill(category.category, index)
                                    }
                                    className="ml-2 text-primary hover:text-primary/80"
                                  >
                                    ×
                                  </button>
                                </span>
                              ))}
                            </div>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                placeholder="Add new skill..."
                                className="flex-1 rounded-md border px-3 py-2"
                                onKeyPress={(e) => {
                                  if (e.key === "Enter") {
                                    const input = e.target as HTMLInputElement;
                                    if (input.value.trim()) {
                                      addSkill(category.category, input.value.trim());
                                      input.value = "";
                                    }
                                  }
                                }}
                              />
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  // TODO: Implement remove category
                                }}
                              >
                                Remove Category
                              </Button>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="projects" className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold mb-6">Projects</h2>
                      <p className="text-muted-foreground">
                        Add your projects to showcase your work.
                      </p>
                    </div>
                  </TabsContent>

                  <TabsContent value="additional" className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold mb-6">Additional Information</h2>
                      <div className="grid gap-6 md:grid-cols-2">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Certifications</label>
                          <textarea
                            className="w-full rounded-md border px-3 py-2"
                            rows={4}
                            placeholder="List your certifications..."
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Languages</label>
                          <textarea
                            className="w-full rounded-md border px-3 py-2"
                            rows={4}
                            placeholder="List languages and proficiency..."
                          />
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </div>
              </ScrollArea>
            </div>
          </Tabs>
        )}
      </div>
    </div>
  );
}