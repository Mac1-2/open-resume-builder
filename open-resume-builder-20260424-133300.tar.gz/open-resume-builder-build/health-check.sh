#!/bin/bash

# Health check script for Open Resume Builder

APP_URL="${APP_URL:-http://localhost:3033}"
DB_HOST="${DB_HOST:-localhost}"
DB_USER="${DB_USER:-openresume}"
DB_PASS="${DB_PASS:-openresume_db_pass}"
DB_NAME="${DB_NAME:-open_resume}"

echo "🔍 Open Resume Builder - Health Check"
echo "====================================="

# Check if application is responding
echo "Checking application..."
if curl -s --max-time 10 "$APP_URL" > /dev/null; then
    echo "✅ Application is responding"
else
    echo "❌ Application is not responding"
    exit 1
fi

# Check database connection
echo "Checking database..."
if mysql -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -e "SELECT 1" &>/dev/null; then
    echo "✅ Database connection OK"
else
    echo "❌ Database connection failed"
    exit 1
fi

# Check if key tables exist
echo "Checking database tables..."
TABLES=$(mysql -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -e "SHOW TABLES;" 2>/dev/null | wc -l)
if [ "$TABLES" -gt 5 ]; then
    echo "✅ Database tables exist ($TABLES tables)"
else
    echo "❌ Database tables missing or incomplete"
    exit 1
fi

echo ""
echo "🎉 All health checks passed!"
