#!/bin/bash

# Open Resume Builder - Complete Deployment Script
# This script installs all dependencies, sets up MariaDB, and deploys the application

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default configuration (can be overridden by user input)
DEFAULT_DB_NAME="open_resume"
DEFAULT_DB_USER="openresume"
DEFAULT_APP_PORT="3033"
DEFAULT_APP_URL="http://localhost:3033"

# Global variables (will be set by user input)
DB_NAME=""
DB_USER=""
DB_PASS=""
DB_ROOT_PASS=""
APP_PORT=""
APP_URL=""
INSTALL_AI="false"
INSTALL_SERVICE="true"
SKIP_DB_SETUP="false"

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Generate a secure random password
generate_password() {
    openssl rand -base64 12 | tr -d "=+/" | cut -c1-16
}

# Configuration function - interactive setup
configure_deployment() {
    echo ""
    echo "🔧 Open Resume Builder - Configuration"
    echo "======================================"
    echo ""

    # Database Configuration
    echo "🗃️  Database Configuration:"
    echo "-------------------------"

    read -p "Database name [$DEFAULT_DB_NAME]: " input_db_name
    DB_NAME="${input_db_name:-$DEFAULT_DB_NAME}"

    read -p "Database user [$DEFAULT_DB_USER]: " input_db_user
    DB_USER="${input_db_user:-$DEFAULT_DB_USER}"

    echo "Database password options:"
    echo "  1. Auto-generate secure password"
    echo "  2. Enter custom password"
    read -p "Choose option [1]: " pass_option

    case ${pass_option:-1} in
        1)
            DB_PASS=$(generate_password)
            log_success "Generated secure password: $DB_PASS"
            ;;
        2)
            read -s -p "Enter database password: " DB_PASS
            echo ""
            read -s -p "Confirm password: " confirm_pass
            echo ""
            if [ "$DB_PASS" != "$confirm_pass" ]; then
                log_error "Passwords do not match"
                exit 1
            fi
            ;;
        *)
            DB_PASS=$(generate_password)
            log_success "Generated secure password: $DB_PASS"
            ;;
    esac

    # Generate root password
    DB_ROOT_PASS=$(generate_password)
    log_info "Generated MariaDB root password: $DB_ROOT_PASS"

    echo ""

    # Application Configuration
    echo "🚀 Application Configuration:"
    echo "----------------------------"

    read -p "Application port [$DEFAULT_APP_PORT]: " input_app_port
    APP_PORT="${input_app_port:-$DEFAULT_APP_PORT}"

    read -p "Application URL [$DEFAULT_APP_URL]: " input_app_url
    APP_URL="${input_app_url:-$DEFAULT_APP_URL}"

    echo ""

    # Feature Selection
    echo "⚙️  Feature Configuration:"
    echo "-----------------------"

    read -p "Install AI features (requires OpenAI API key) [y/N]: " ai_choice
    case ${ai_choice:-n} in
        [Yy]|[Yy][Ee][Ss])
            INSTALL_AI="true"
            log_info "AI features will be configured"
            ;;
        *)
            INSTALL_AI="false"
            log_info "AI features will be skipped"
            ;;
    esac

    read -p "Install systemd service for auto-start [Y/n]: " service_choice
    case ${service_choice:-y} in
        [Nn]|[Nn][Oo])
            INSTALL_SERVICE="false"
            log_warn "Systemd service will NOT be installed"
            ;;
        *)
            INSTALL_SERVICE="true"
            log_info "Systemd service will be installed"
            ;;
    esac

    echo ""

    # Summary
    echo "📋 Configuration Summary:"
    echo "========================="
    echo "Database Name: $DB_NAME"
    echo "Database User: $DB_USER"
    echo "Database Password: $DB_PASS"
    echo "MariaDB Root Password: $DB_ROOT_PASS"
    echo "Application Port: $APP_PORT"
    echo "Application URL: $APP_URL"
    echo "Install AI Features: $INSTALL_AI"
    echo "Install Systemd Service: $INSTALL_SERVICE"
    echo ""

    read -p "Continue with this configuration? [Y/n]: " confirm
    case ${confirm:-y} in
        [Nn]|[Nn][Oo])
            log_info "Deployment cancelled by user"
            exit 0
            ;;
        *)
            log_info "Starting deployment..."
            ;;
    esac
}

# Parse command line arguments for non-interactive mode
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --db-name=*)
                DB_NAME="${1#*=}"
                ;;
            --db-user=*)
                DB_USER="${1#*=}"
                ;;
            --db-pass=*)
                DB_PASS="${1#*=}"
                ;;
            --app-port=*)
                APP_PORT="${1#*=}"
                ;;
            --app-url=*)
                APP_URL="${1#*=}"
                ;;
            --with-ai)
                INSTALL_AI="true"
                ;;
            --no-service)
                INSTALL_SERVICE="false"
                ;;
            --skip-db)
                SKIP_DB_SETUP="true"
                ;;
            --help|-h)
                show_help
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
        shift
    done
}

# Show help
show_help() {
    echo "Open Resume Builder - Deployment Script"
    echo ""
    echo "Usage: $0 [options]"
    echo ""
    echo "Interactive Mode (recommended):"
    echo "  $0"
    echo ""
    echo "Non-Interactive Mode:"
    echo "  $0 --db-name=mydb --db-user=myuser --db-pass=mypass --app-port=3000"
    echo ""
    echo "Options:"
    echo "  --db-name=NAME     Database name (default: open_resume)"
    echo "  --db-user=USER     Database user (default: openresume)"
    echo "  --db-pass=PASS     Database password (auto-generated if not provided)"
    echo "  --app-port=PORT    Application port (default: 3033)"
    echo "  --app-url=URL      Application URL (default: http://localhost:3033)"
    echo "  --with-ai           Enable AI features"
    echo "  --no-service        Skip systemd service installation"
    echo "  --skip-db           Skip database setup (use existing)"
    echo "  --help, -h          Show this help"
    echo ""
    echo "Examples:"
    echo "  $0  # Interactive setup"
    echo "  $0 --db-name=myresume --app-port=8080 --with-ai"
    echo "  $0 --skip-db --no-service  # Use existing DB, don't install service"
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        log_error "This script should not be run as root for security reasons."
        log_info "The script will use sudo when necessary."
        exit 1
    fi
}

# Detect OS and package manager
detect_os() {
    if command -v apt &> /dev/null; then
        OS="debian"
        PACKAGE_MANAGER="apt"
        UPDATE_CMD="sudo apt update"
        INSTALL_CMD="sudo apt install -y"
        log_info "Detected Debian/Ubuntu system"
    elif command -v yum &> /dev/null; then
        OS="redhat"
        PACKAGE_MANAGER="yum"
        UPDATE_CMD="sudo yum update -y"
        INSTALL_CMD="sudo yum install -y"
        log_info "Detected Red Hat/CentOS system"
    elif command -v dnf &> /dev/null; then
        OS="fedora"
        PACKAGE_MANAGER="dnf"
        UPDATE_CMD="sudo dnf update -y"
        INSTALL_CMD="sudo dnf install -y"
        log_info "Detected Fedora system"
    else
        log_error "Unsupported operating system. This script supports Debian/Ubuntu (apt) and Red Hat/Fedora (yum/dnf)."
        exit 1
    fi
}

# Install Node.js and npm
install_nodejs() {
    log_info "Installing Node.js and npm..."

    if [[ "$OS" == "debian" ]]; then
        # Install Node.js 18+ from NodeSource
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
        $INSTALL_CMD nodejs
    elif [[ "$OS" == "redhat" ]] || [[ "$OS" == "fedora" ]]; then
        # Install Node.js from NodeSource RPM
        curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
        $INSTALL_CMD nodejs
    fi

    # Verify installation
    node_version=$(node --version)
    npm_version=$(npm --version)
    log_success "Node.js $node_version installed"
    log_success "npm $npm_version installed"
}

# Install MariaDB
install_mariadb() {
    log_info "Installing MariaDB..."

    if [[ "$OS" == "debian" ]]; then
        $INSTALL_CMD mariadb-server mariadb-client
    elif [[ "$OS" == "redhat" ]] || [[ "$OS" == "fedora" ]]; then
        if [[ "$OS" == "fedora" ]]; then
            $INSTALL_CMD mariadb-server mariadb
        else
            $INSTALL_CMD mariadb-server mariadb
        fi
    fi

    log_success "MariaDB installed"
}

# Configure MariaDB
configure_mariadb() {
    if [[ "$SKIP_DB_SETUP" == "true" ]]; then
        log_warn "Skipping MariaDB configuration (--skip-db)"
        return
    fi

    log_info "Configuring MariaDB..."

    # Start MariaDB service
    if [[ "$OS" == "debian" ]]; then
        sudo systemctl start mariadb
        sudo systemctl enable mariadb
    elif [[ "$OS" == "redhat" ]] || [[ "$OS" == "fedora" ]]; then
        if command -v systemctl &> /dev/null; then
            sudo systemctl start mariadb
            sudo systemctl enable mariadb
        else
            sudo service mariadb start
            sudo chkconfig mariadb on
        fi
    fi

    log_success "MariaDB service started"

    # Secure MariaDB installation (non-interactive)
    log_info "Securing MariaDB installation..."

    # Create secure installation script with custom root password
    cat > /tmp/mariadb_secure.sql << EOF
-- Secure MariaDB installation
UPDATE mysql.user SET Password=PASSWORD('$DB_ROOT_PASS') WHERE User='root';
DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');
DELETE FROM mysql.user WHERE User='' AND Host='localhost';
DELETE FROM mysql.db WHERE Db='test' OR Db='test_%';
FLUSH PRIVILEGES;
EOF

    # Execute secure installation
    sudo mysql < /tmp/mariadb_secure.sql

    # Clean up
    rm /tmp/mariadb_secure.sql

    log_success "MariaDB secured with root password: $DB_ROOT_PASS"
}

# Create database and user
setup_database() {
    if [[ "$SKIP_DB_SETUP" == "true" ]]; then
        log_warn "Skipping database setup (--skip-db)"
        return
    fi

    log_info "Creating database and user..."

    # Create database and user
    cat > /tmp/create_db.sql << EOF
CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON $DB_NAME.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;
EOF

    # Execute as root
    sudo mysql -u root -p"$DB_ROOT_PASS" < /tmp/create_db.sql

    # Clean up
    rm /tmp/create_db.sql

    log_success "Database '$DB_NAME' created"
    log_success "User '$DB_USER' created with password: $DB_PASS"
}

# Install project dependencies
install_project_deps() {
    log_info "Installing project dependencies..."

    cd /home/mike/open-resume

    # Install npm dependencies
    npm install

    log_success "Project dependencies installed"
}

# Configure environment
configure_environment() {
    log_info "Configuring environment variables..."

    cd /home/mike/open-resume

    # Create .env.local if it doesn't exist
    if [ ! -f .env.local ]; then
        cp .env.example .env.local
    fi

    # Update database URL
    sed -i "s|DATABASE_URL=\"mysql://.*\"|DATABASE_URL=\"mysql://$DB_USER:$DB_PASS@localhost:3306/$DB_NAME\"|g" .env.local

    # Set application port and URL
    sed -i "s|NEXT_PUBLIC_APP_URL=\"http://localhost:3000\"|NEXT_PUBLIC_APP_URL=\"$APP_URL\"|g" .env.local

    # Set port if different from default
    if [[ "$APP_PORT" != "3000" ]]; then
        echo "PORT=$APP_PORT" >> .env.local
    fi

    # Add optional OpenAI key placeholder if AI is enabled
    if [[ "$INSTALL_AI" == "true" ]]; then
        if ! grep -q "OPENAI_API_KEY" .env.local; then
            echo 'OPENAI_API_KEY=""' >> .env.local
            log_info "OpenAI API key placeholder added. Add your key to enable AI features."
        fi
    fi

    log_success "Environment configured (.env.local)"
}

# Setup database schema
setup_schema() {
    if [[ "$SKIP_DB_SETUP" == "true" ]]; then
        log_warn "Skipping schema setup (--skip-db)"
        return
    fi

    log_info "Setting up database schema..."

    cd /home/mike/open-resume

    # Push schema to database
    npx prisma db push

    # Seed database with sample data
    npm run db:seed

    log_success "Database schema created and seeded"
}

# Build the application
build_application() {
    log_info "Building application for production..."

    cd /home/mike/open-resume

    npm run build

    log_success "Application built successfully"
}

# Create systemd service
create_service() {
    if [[ "$INSTALL_SERVICE" == "false" ]]; then
        log_warn "Skipping systemd service creation (--no-service)"
        return
    fi

    log_info "Creating systemd service for production deployment..."

    cat > /tmp/open-resume.service << EOF
[Unit]
Description=Open Resume Builder
After=network.target mariadb.service
Requires=mariadb.service

[Service]
Type=simple
User=$USER
WorkingDirectory=/home/mike/open-resume
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
Environment=NODE_ENV=production
Environment=PORT=$APP_PORT

[Install]
WantedBy=multi-user.target
EOF

    sudo mv /tmp/open-resume.service /etc/systemd/system/

    # Reload systemd and enable service
    sudo systemctl daemon-reload
    sudo systemctl enable open-resume

    log_success "Systemd service created: open-resume"
}

# Start the application
start_application() {
    log_info "Starting Open Resume Builder..."

    if [[ "$INSTALL_SERVICE" == "true" ]]; then
        # Start using systemd
        sudo systemctl start open-resume

        # Wait and check
        sleep 3
        if sudo systemctl is-active --quiet open-resume; then
            log_success "Open Resume Builder started successfully!"
            log_info "Service status: $(sudo systemctl is-active open-resume)"
        else
            log_error "Failed to start service. Check logs with: sudo journalctl -u open-resume"
            exit 1
        fi
    else
        # Start directly (development mode)
        cd /home/mike/open-resume
        log_info "Starting in development mode..."
        npm run dev &
        sleep 3

        if pgrep -f "next dev" > /dev/null; then
            log_success "Open Resume Builder started in development mode!"
        else
            log_error "Failed to start application in development mode"
            exit 1
        fi
    fi

    log_info "Application URL: $APP_URL"
    log_info "Resume Editor: $APP_URL/editor"
}

# Main deployment function
main() {
    echo "🚀 Open Resume Builder - Interactive Deployment"
    echo "=============================================="
    echo ""

    # Parse command line arguments first
    parse_args "$@"

    # Check if running in non-interactive mode (all vars set via args)
    if [[ -n "$DB_NAME" && -n "$DB_USER" && -n "$DB_PASS" && -n "$APP_PORT" && -n "$APP_URL" ]]; then
        log_info "Running in non-interactive mode with provided arguments"
    else
        # Interactive configuration
        configure_deployment
    fi

    # Set defaults if not provided
    DB_NAME="${DB_NAME:-$DEFAULT_DB_NAME}"
    DB_USER="${DB_USER:-$DEFAULT_DB_USER}"
    DB_PASS="${DB_PASS:-$(generate_password)}"
    DB_ROOT_PASS="${DB_ROOT_PASS:-$(generate_password)}"
    APP_PORT="${APP_PORT:-$DEFAULT_APP_PORT}"
    APP_URL="${APP_URL:-$DEFAULT_APP_URL}"

    check_root
    detect_os

    echo ""
    log_info "Starting deployment process..."
    echo ""

    # Step 1: Update system
    log_info "Step 1: Updating system packages..."
    $UPDATE_CMD

    # Step 2: Install Node.js
    echo ""
    log_info "Step 2: Installing Node.js..."
    install_nodejs

    # Step 3: Install MariaDB
    echo ""
    log_info "Step 3: Installing MariaDB..."
    install_mariadb

    # Step 4: Configure MariaDB
    echo ""
    log_info "Step 4: Configuring MariaDB..."
    configure_mariadb

    # Step 5: Setup database
    echo ""
    log_info "Step 5: Setting up database..."
    setup_database

    # Step 6: Install project dependencies
    echo ""
    log_info "Step 6: Installing project dependencies..."
    install_project_deps

    # Step 7: Configure environment
    echo ""
    log_info "Step 7: Configuring environment..."
    configure_environment

    # Step 8: Setup schema
    echo ""
    log_info "Step 8: Setting up database schema..."
    setup_schema

    # Step 9: Build application
    echo ""
    log_info "Step 9: Building application..."
    build_application

    # Step 10: Create service
    echo ""
    log_info "Step 10: Creating systemd service..."
    create_service

    # Step 11: Start application
    echo ""
    log_info "Step 11: Starting application..."
    start_application

    echo ""
    echo "🎉 DEPLOYMENT COMPLETE!"
    echo "======================"
    echo ""
    log_success "Open Resume Builder is now running!"
    echo ""
    echo "📊 Access URLs:"
    echo "   • Homepage:     $APP_URL"
    echo "   • Resume Editor: $APP_URL/editor"
    echo ""
    if [[ "$INSTALL_SERVICE" == "true" ]]; then
        echo "🔧 Management Commands:"
        echo "   • Status:       sudo systemctl status open-resume"
        echo "   • Restart:      sudo systemctl restart open-resume"
        echo "   • Stop:         sudo systemctl stop open-resume"
        echo "   • Logs:         sudo journalctl -u open-resume -f"
    fi
    echo ""
    echo "🗃️ Database Credentials:"
    echo "   • Host: localhost:3306"
    echo "   • Database: $DB_NAME"
    echo "   • User: $DB_USER"
    echo "   • Password: $DB_PASS"
    echo "   • Root Password: $DB_ROOT_PASS"
    echo ""
    if [[ "$INSTALL_AI" == "true" ]]; then
        echo "🤖 AI Features:"
        echo "   Add your OpenAI API key to .env.local to enable AI chat"
        echo ""
    fi
    echo "📝 Next Steps:"
    if [[ "$INSTALL_SERVICE" == "true" ]]; then
        echo "   1. Visit $APP_URL to start using the app"
        echo "   2. Configure OpenAI API key for AI features (optional)"
        echo "   3. Set up a reverse proxy (nginx) for production"
        echo "   4. Configure SSL certificates"
    else
        echo "   1. Visit $APP_URL to start using the app"
        echo "   2. The app is running in development mode (Ctrl+C to stop)"
        echo "   3. Configure OpenAI API key for AI features (optional)"
    fi
    echo ""
}

# Handle command line arguments
case "${1:-}" in
    "--help"|"-h")
        show_help
        exit 0
        ;;
    *)
        main "$@"
        ;;
esac