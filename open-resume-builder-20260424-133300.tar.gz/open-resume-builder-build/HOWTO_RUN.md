# How to Run Open Resume Builder

## Prerequisites

- **Node.js** (v18 or higher)
- **npm** (v9 or higher) or **yarn** (v1.22+)
- **MariaDB** (v10.5+) or **MySQL** (v8.0+)
- **Git** (optional, for cloning the repository)

## Quick Start

### 1. Clone Repository

```bash
cd /home/mike/open-resume
# or if cloning from git:
# git clone https://github.com/your-org/open-resume.git
# cd open-resume
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Configure Environment

Copy the example environment file:

```bash
cp .env.example .env.local
```

Edit `.env.local` to configure your database connection:

```bash
DATABASE_URL="mysql://youruser:yourpassword@localhost:3306/open_resume"
```

### 4. Set Up MariaDB Database

#### Option A: Ubuntu/Debian (MariaDB)

```bash
# Install MariaDB
sudo apt update
sudo apt install mariadb-server mariadb-client

# Start the service
sudo systemctl start mariadb
sudo systemctl enable mariadb

# Secure installation
sudo mysql_secure_installation
```

#### Option B: macOS (Homebrew)

```bash
brew install mariadb
brew services start mariadb
```

#### Option C: Docker (Recommended for Development)

```bash
docker run -d \
  --name mariadb-openresume \
  -e MARIADB_ROOT_PASSWORD=password \
  -e MARIADB_DATABASE=open_resume \
  -p 3306:3306 \
  mariadb:10.11
```

### 5. Create Database and User

Once MariaDB is running:

```bash
# Connect as root (with password if set)
mysql -u root -p

# In MySQL shell, create database and user:
CREATE DATABASE open_resume CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'openresume'@'localhost' IDENTIFIED BY 'your-strong-password';
GRANT ALL PRIVILEGES ON open_resume.* TO 'openresume'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

Update your `.env.local` with the correct credentials:

```bash
DATABASE_URL="mysql://openresume:your-strong-password@localhost:3306/open_resume"
```

If using root with password:

```bash
DATABASE_URL="mysql://root:password@localhost:3306/open_resume"
```

### 6. Initialize Database Schema

Apply the Prisma schema to your database:

```bash
npx prisma db push
```

This creates all necessary tables:
- `users` - User accounts
- `resumes` - Resume data
- `templates` - CV templates
- `resume_sections` - Structured resume sections
- `a_i_chats` - AI chat history
- `settings` - Application settings

### 7. Seed Sample Data (Optional)

Populate the database with sample templates and a demo resume:

```bash
npm run db:seed
```

This creates:
- 5 modern CV templates (Professional, Modern, Creative, Minimal, Tech)
- Admin user account
- Sample resume data for testing

### 8. Start Development Server

```bash
npm run dev
```

Open [http://localhost:3033](http://localhost:3033) in your browser.

### 9. Access Prisma Studio (Optional)

View and manage your database through a web interface:

```bash
npm run db:studio
```

Open [http://localhost:5555](http://localhost:5555)

## Production Deployment

### Build Application

```bash
npm run build
npm start
```

### Environment Variables for Production

Ensure these are set in your production environment:

```bash
DATABASE_URL="mysql://user:pass@production-host:3306/open_resume"
OPENAI_API_KEY="sk-your-production-key"  # For AI features
NEXT_PUBLIC_APP_URL="https://your-domain.com"
```

## Using the Application

### Creating Your First Resume

1. **Open the Editor**: Navigate to `/editor` route or use the start page
2. **Select Template**: Click "Templates" button to choose a CV design
3. **Add Personal Info**: Fill in name, email, phone, location, title, summary
4. **Add Sections**: 
   - **Experience**: Company, position, dates, achievements
   - **Education**: Institution, degree, field, dates
   - **Skills**: Technical and soft skills with proficiency levels
   - **Projects**: Portfolio highlights
   - **Languages**: Languages spoken and proficiency levels
5. **Live Preview**: View updates in the right panel
6. **AI Assistance**: Use the AI chat below preview for:
   - Improving summary statements
   - Skills suggestions
   - Grammar checking
   - ATS optimization
   - Experience bullet rewrites
7. **Download**: Click "Download PDF" to export your resume

### AI Chat Features

The AI Assistant provides:

- **Improve Summary**: Rewrites professional summaries with more impact
- **Skills Suggestions**: Recommends relevant skills for your industry
- **Grammar Check**: Reviews for spelling and grammar errors
- **Tailor to Job**: Aligns your resume with job descriptions
- **Rewrite Bullets**: Transforms weak bullets into compelling achievements
- **ATS Optimization**: Ensures resume passes automated screening

Quick action buttons are available above the chat interface.

### Template Gallery

5 modern CV templates included:

- **Professional Executive**: Classic two-column design, ideal for corporate roles
- **Modern Clean**: Minimal single-column with accent colors, great for tech
- **Creative Bold**: Asymmetric layout with gradients, perfect for designers
- **Minimal Swiss**: Ultra-clean with typography focus, excellent for academics
- **Tech Developer**: Dark theme with monospace accents, built for engineers

## Troubleshooting

### Database Connection Errors

```bash
# Verify MariaDB is running
sudo systemctl status mariadb

# Check connection string in .env.local
cat .env.local

# Test connection
mysql -u openresume -p open_resume
```

### Prisma Errors

```bash
# Regenerate Prisma client
npx prisma generate

# Reset and recreate database
npx prisma db push --force-reset

# Re-seed sample data
npm run db:seed
```

### Port Already in Use

```bash
# Change port in package.json scripts
"dev": "next dev -p 3001"

# Or use environment variable
PORT=3001 npm run dev
```

### Build Failures

```bash
# Clear Next.js cache
rm -rf .next

# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install

# Rebuild
npm run build
```

## Development

### Available Scripts

- `npm run dev` - Start development server (http://localhost:3033)
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run lint` - Run ESLint
- `npm run db:push` - Sync Prisma schema with database
- `npm run db:studio` - Open Prisma Studio GUI
- `npm run db:seed` - Seed database with sample data

### Adding New CV Templates

1. Create a new component in `/src/components/resume/templates/MyTemplate.tsx`
2. Export as default:

```typescript
export default function MyTemplate({ data }: { data: ResumeData }) {
  return <div>Your template JSX</div>;
}
```

3. Update the index file:

```typescript
export { default as MyTemplate } from './MyTemplate';
```

4. Update the template selector to include your template

### Database Schema

Key tables defined in `prisma/schema.prisma`:

- **User**: `id`, `email`, `name`, `createdAt`, `updatedAt`
- **Resume**: `id`, `userId`, `title`, `template`, `data(JSON)`, timestamps
- **Template**: `id`, `name`, `description`, `config(JSON)`, `isActive`, `category`, `tags(JSON)`, `popularity`
- **ResumeSection**: `id`, `resumeId`, `type`, `content(JSON)`, `order`, `isVisible`
- **AIChat**: `id`, `resumeId`, `userId`, `messages(JSON)`, timestamps

## Security Notes

- Always use HTTPS in production
- Keep OpenAI API keys secret (use environment variables)
- Never commit `.env.local` to version control
- Use parameterized queries (Prisma handles this)
- Implement authentication for user accounts
- Validate and sanitize all user inputs

## Support & Contributing

- Issue tracker: GitHub Issues
- Documentation: See inline code comments
- License: MIT

## Environment Configuration Examples

### Development (.env.local)

```bash
DATABASE_URL="mysql://root:password@localhost:3306/open_resume"
OPENAI_API_KEY="sk-your-dev-key"
NEXT_PUBLIC_APP_URL="http://localhost:3033"
NODE_ENV="development"
```

### Production (.env.production)

```bash
DATABASE_URL="mysql://user:password@db.example.com:3306/open_resume"
OPENAI_API_KEY="sk-your-prod-key"
NEXT_PUBLIC_APP_URL="https://resume.example.com"
NODE_ENV="production"
```

### Docker Deployment

```yaml
# docker-compose.yml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3033:3033"
    environment:
      - DATABASE_URL=mysql://user:pass@db:3306/open_resume
    depends_on:
      - db
  
  db:
    image: mariadb:10.11
    environment:
      MARIADB_ROOT_PASSWORD: password
      MARIADB_DATABASE: open_resume
      MYSQL_USER: user
      MYSQL_PASSWORD: pass
    volumes:
      - mariadb_data:/var/lib/mysql
    ports:
      - "3306:3306"

volumes:
  mariadb_data:
```

## Performance Tips

- Use `npm run build` before deploying
- Enable gzip compression on your web server
- Use a CDN for static assets
- Implement caching for API responses
- Keep images optimized and compressed
- Lazy load non-critical components

## License

MIT © 2026
