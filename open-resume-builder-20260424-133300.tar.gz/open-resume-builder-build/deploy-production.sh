#!/bin/bash

# Production Deployment Script
# Run this script on your production server after extracting the archive

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

echo "🚀 Open Resume Builder - Production Server Deployment"
echo "======================================================"
echo ""

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    log_error "Do not run as root. Use a regular user with sudo access."
    exit 1
fi

# Check if .env.local exists
if [ ! -f .env.local ]; then
    log_warn ".env.local not found. Copying from .env.production..."
    cp .env.production .env.local
    log_warn "Please edit .env.local with your production settings before continuing."
    read -p "Press Enter after configuring .env.local..."
fi

log_info "Installing Node.js dependencies..."
npm ci --only=production

log_info "Building application..."
npm run build

log_info "Setting up database..."
npx prisma db push

log_info "Seeding database..."
npm run db:seed

log_info "Starting application..."
npm start

log_success "Deployment complete!"
log_info "Application should be running on the configured port"
